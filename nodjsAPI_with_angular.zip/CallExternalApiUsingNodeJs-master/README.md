# CallExternalApiUsingNodeJs

#Step By Step Tutorial 

[![Call External API using Node JS](https://img.youtube.com/vi/ZbtZ_79UmjI/0.jpg)](https://www.youtube.com/watch?v=ZbtZ_79UmjI)
